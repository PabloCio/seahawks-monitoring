#Fonction de db

def export_db():
    x = 0