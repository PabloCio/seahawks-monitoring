#Fonction de scan

def scan_network():
    x = 0