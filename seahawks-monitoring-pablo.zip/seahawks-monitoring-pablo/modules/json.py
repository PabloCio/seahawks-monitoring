# Export en JSON
import json

def export_json():
    x = 0
